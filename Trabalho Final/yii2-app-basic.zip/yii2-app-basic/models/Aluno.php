<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "aluno".
 *
 * @property integer $id
 * @property integer $matricula
 * @property string $nome
 * @property string $sexo
 * @property integer $id_curso
 * @property integer $ano_ingresso
 */
class Aluno extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'aluno';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['matricula', 'ano_ingresso'], 'integer'],
            [['nome'], 'string', 'max' => 200],
            [['matricula'], 'unique'],
            [['matricula', 'id_curso', 'ano_ingresso','nome', 'sexo'], 'required','message'=>'Este campo é obrigatório'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'matricula' => 'Matrícula',
            'nome' => 'Nome',
            'sexo' => 'Sexo',
            'id_curso' => 'Curso',
            'ano_ingresso' => 'Ano de Ingresso',
        ];
    }

    public function afterFind(){

        if(strcmp($this->sexo, 'M') ==0)
            $this->sexo = 'Masculino';
        else{
            if(strcmp($this->sexo, 'F') ==0)
                $this->sexo = 'Feminino';
        }

        $this->nome = ucwords(strtolower($this->nome));

        $this->id_curso = Curso::findOne($this->id_curso)->nome;
    }
}
