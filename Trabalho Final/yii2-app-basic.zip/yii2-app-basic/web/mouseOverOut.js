function onMouseOver(text){
	text.style.color='red';
}
function onMouseOut(text){
	text.style.removeProperty('color');
}